# This file is a part of TG-FileStreamBot
# Coding : Jyothis Jayanth [@EverythingSuckz]

from .file_properties import get_hash, get_name
from .custom_dl import ByteStreamer
